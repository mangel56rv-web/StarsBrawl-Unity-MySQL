using TMPro;
using UnityEngine;
using UnityEngine.UI;
using MySqlConnector;
using System.Collections.Generic;

public class MatchDetails : MonoBehaviour
{
    [Header("UI General")]
    [SerializeField] private TMP_Text matchResultTitleText;

    [Header("Contenedores de Jugadores")]
    [SerializeField] private List<GameObject> playerSlots;

    private void Start()
    {
        CargarDetallesDeLaPartida();
    }

    private void CargarDetallesDeLaPartida()
    {
        string matchId = DatabaseManager.SelectedMatchId;
        // ID de seguridad por si ejecutas la escena suelta en el editor
        if (string.IsNullOrEmpty(matchId)) matchId = "1";

        // 1. Cargar el Resultado (Victoria/Derrota) de la partida en el encabezado
        string queryGeneral = @"
            SELECT result 
            FROM match_user 
            WHERE match_id = @mId AND user_id = @uId LIMIT 1;";

        MySqlParameter[] pGen = {
            new MySqlParameter("@mId", matchId),
            new MySqlParameter("@uId", DatabaseManager.Instance != null && !string.IsNullOrEmpty(DatabaseManager.CurrentUserId) ? DatabaseManager.CurrentUserId : "#5BE3693F00")
        };

        DatabaseManager.Instance.ExecuteQuery(queryGeneral, (readerGen) => {
            if (readerGen.Read())
            {
                string resultadoReal = readerGen["result"].ToString().ToUpper();

                if (matchResultTitleText != null)
                {
                    matchResultTitleText.text = resultadoReal;
                }
                else
                {
                    TMP_Text t = GameObject.Find("Brawlers Text")?.GetComponent<TMP_Text>();
                    if (t != null) t.text = resultadoReal;
                }
            }
        }, pGen);

        // 2. Consulta de los 6 jugadores vinculados estrictamente a la ID de esta partida
        string queryPlayers = @"
            SELECT users.nickname, brawlers.name
            FROM match_user
            INNER JOIN users ON match_user.user_id = users.user_id
            INNER JOIN brawlers ON match_user.brawler_id = brawlers.brawler_id
            WHERE match_user.match_id = @mId
            ORDER BY match_user.result DESC 
            LIMIT 6;";

        MySqlParameter[] pPlayers = {
            new MySqlParameter("@mId", matchId)
        };

        DatabaseManager.Instance.ExecuteQuery(queryPlayers, (reader) => {
            int index = 0;
            while (reader.Read() && index < playerSlots.Count)
            {
                string playerName = reader.GetString(0);
                string brawlerName = reader.GetString(1);

                ActualizarSlotJugador(playerSlots[index], playerName, brawlerName);
                index++;
            }
        }, pPlayers);
    }

    private void ActualizarSlotJugador(GameObject slot, string pName, string bName)
    {
        slot.SetActive(true);

        // Datos est�ticos realistas para simular las copas y niveles en la interfaz
        string copasFijas = "500";
        string nivelFijo = "NIVEL 10";

        // 1. Actualizar los cuadros de texto internos (Nombre, Copas y Nivel)
        TMP_Text[] textos = slot.GetComponentsInChildren<TMP_Text>(true);
        foreach (TMP_Text t in textos)
        {
            if (t.gameObject.name == "User Nickname Text") t.text = pName.ToUpper();
            else if (t.gameObject.name == "Brawler Trophies Amount") t.text = copasFijas;
            else if (t.gameObject.name == "Brawler Level Text") t.text = nivelFijo;
        }

        // 2. Buscar el componente Image llamado "Brawler Image" dentro del Slot
        Image brawlerImg = null;
        Image[] todasLasImagenes = slot.GetComponentsInChildren<Image>(true);
        foreach (Image img in todasLasImagenes)
        {
            if (img.gameObject.name == "Brawler Image")
            {
                brawlerImg = img;
                break;
            }
        }

        // 3. Cargar el Sprite desde la carpeta Resources con el formato exacto: nombre_portrait
        if (brawlerImg != null)
        {
            string nombreLimpio = bName.Trim().ToLower();
            string nombreArchivoReal = nombreLimpio + "_portrait";

            // Intenta buscar el archivo en la ra�z de Resources o en sus subcarpetas habituales
            Sprite brawlerSprite = Resources.Load<Sprite>(nombreArchivoReal);
            if (brawlerSprite == null) brawlerSprite = Resources.Load<Sprite>("Brawlers/" + nombreArchivoReal);
            if (brawlerSprite == null) brawlerSprite = Resources.Load<Sprite>("Brawlers/Portraits/" + nombreArchivoReal);

            if (brawlerSprite != null)
            {
                brawlerImg.sprite = brawlerSprite;
                brawlerImg.color = Color.white; // Asegura que no tenga transparencias u opacidad activa
                Debug.Log("Imagen cargada con �xito desde BD: " + nombreArchivoReal);
            }
            else
            {
                Debug.LogWarning("No se pudo encontrar el archivo de imagen en Resources: " + nombreArchivoReal);
            }
        }
    }

    public void OnBackButtonClick()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("BattleLog");
    }
}
