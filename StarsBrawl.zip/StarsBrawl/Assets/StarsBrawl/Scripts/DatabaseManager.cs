using System;
using MySqlConnector;
using UnityEngine;
using UnityEngine.SceneManagement; 
using TMPro;

public class DatabaseManager : MonoBehaviour
{
    public static DatabaseManager Instance { get; private set; }

    [Header("Database Configuration")]
    [SerializeField] private string connectionString = "Server=127.0.0.1;Port=3306;Database=brawl_stars;User ID=root;Password=root;Pooling=true;";

    [Header("UI Login Elements")]
    [SerializeField] private TMP_InputField idInputField;

    
    public static string CurrentUserId { get; private set; }
    public static string SelectedBrawlerId { get; set; }
    public static string SelectedMatchId { get; set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

   
    public void OnConfirmButtonClick()
    {
        if (idInputField == null || string.IsNullOrEmpty(idInputField.text))
        {
            Debug.LogWarning("[LOGIN] Por favor, introduce un ID de jugador.");
            return;
        }

        string inputId = idInputField.text.Trim();
        string query = "SELECT COUNT(*) FROM users WHERE user_id = @userId;";

        MySqlParameter[] parameters = { new MySqlParameter("@userId", inputId) };
        bool userExists = false;

        MySqlConnection connection = new MySqlConnection(connectionString);
        MySqlCommand command = new MySqlCommand(query, connection);
        command.Parameters.AddRange(parameters);

        try
        {
            connection.Open();
            int count = Convert.ToInt32(command.ExecuteScalar());
            userExists = count > 0;
        }
        catch (Exception ex)
        {
            Debug.LogError($"[DB LOGIN ERROR] {ex.Message}");
        }
        finally
        {
            connection.Close();
            connection.Dispose();
            command.Dispose();
        }

        if (userExists)
        {
            CurrentUserId = inputId;
            Debug.Log($"[LOGIN] ��xito! Cargando MainMenu para el usuario: {CurrentUserId}");

            
            SceneManager.LoadScene("MainMenu");
        }
        else
        {
            Debug.LogError($"[LOGIN] El usuario {inputId} no existe en la base de datos.");
        }
    }

    
    public void ExecuteQuery(string query, Action<MySqlDataReader> callback, MySqlParameter[] parameters = null)
    {
        MySqlConnection connection = new MySqlConnection(connectionString);
        MySqlCommand command = new MySqlCommand(query, connection);

        if (parameters != null)
        {
            command.Parameters.AddRange(parameters);
        }

        try
        {
            connection.Open();
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                callback?.Invoke(reader);
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"[DB EXECUTE ERROR] {ex.Message}");
        }
        finally
        {
            connection.Close();
            connection.Dispose();
            command.Dispose();
        }
    }
}
