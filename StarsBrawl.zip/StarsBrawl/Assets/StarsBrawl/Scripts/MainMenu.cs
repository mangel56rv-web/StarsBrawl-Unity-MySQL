using TMPro;
using UnityEngine;
using MySqlConnector;

public class MainMenu : MonoBehaviour
{
    [Header("Top Bar Components")]
    [SerializeField] private TMP_Text nicknameText;
    [SerializeField] private TMP_Text coinsText;
    [SerializeField] private TMP_Text gemsText;
    [SerializeField] private TMP_Text blingText;
    [SerializeField] private TMP_Text trophiesText;

    [Header("Last Match Components")]
    [SerializeField] private TMP_Text lastBrawlerText;
    [SerializeField] private TMP_Text lastBrawlerTrophiesText;
    [SerializeField] private TMP_Text lastBrawlerLevelText;

    private void Start()
    {
        CargarDatosMenuPrincipal();
    }

    private void CargarDatosMenuPrincipal()
    {
       
        string idUsuarioActual = "#022A276188";
        if (DatabaseManager.Instance != null && !string.IsNullOrEmpty(DatabaseManager.CurrentUserId))
        {
            idUsuarioActual = DatabaseManager.CurrentUserId;
        }

       
        string userQuery = @"
            SELECT u.nickname, u.bling, u.coins, u.gems, IFNULL(SUM(ub.trophies), 0) AS total_trophies 
            FROM users u 
            LEFT JOIN user_brawlers ub ON u.user_id = ub.user_id 
            WHERE u.user_id = @userId 
            GROUP BY u.user_id;";

        MySqlParameter[] userParams = { new MySqlParameter("@userId", idUsuarioActual) };

        DatabaseManager.Instance.ExecuteQuery(userQuery, (reader) =>
        {
            if (reader.Read())
            {
                nicknameText.text = reader["nickname"].ToString();
                coinsText.text = reader["coins"].ToString();
                gemsText.text = reader["gems"].ToString();
                blingText.text = reader["bling"].ToString();
                trophiesText.text = reader["total_trophies"].ToString();
            }
        }, userParams);

        
        string brawlerQuery = @"
            SELECT b.name, ub.trophies, ub.level 
            FROM match_user mu
            INNER JOIN brawlers b ON mu.brawler_id = b.brawler_id
            INNER JOIN user_brawlers ub ON mu.user_id = ub.user_id AND mu.brawler_id = ub.brawler_id
            WHERE mu.user_id = @userId
            ORDER BY mu.match_id DESC 
            LIMIT 1;";

        MySqlParameter[] brawlerParams = { new MySqlParameter("@userId", idUsuarioActual) };

        DatabaseManager.Instance.ExecuteQuery(brawlerQuery, (reader) =>
        {
            if (reader.Read())
            {
                lastBrawlerText.text = reader["name"].ToString().ToUpper();
                lastBrawlerLevelText.text = reader["level"].ToString();
                lastBrawlerTrophiesText.text = reader["trophies"].ToString();
            }
            else
            {
                
               
                CargarBrawlerDeReserva();
            }
        }, brawlerParams);
    }

    private void CargarBrawlerDeReserva()
    {
       
        string userConDatos = "#022A276188";

        string defaultQuery = @"
            SELECT b.name, ub.trophies, ub.level 
            FROM user_brawlers ub
            INNER JOIN brawlers b ON ub.brawler_id = b.brawler_id
            WHERE ub.user_id = @userId
            LIMIT 1;";

        MySqlParameter[] defParams = { new MySqlParameter("@userId", userConDatos) };

        DatabaseManager.Instance.ExecuteQuery(defaultQuery, (readerDef) =>
        {
            if (readerDef.Read())
            {
                lastBrawlerText.text = readerDef["name"].ToString().ToUpper();
                lastBrawlerLevelText.text = readerDef["level"].ToString();
                lastBrawlerTrophiesText.text = readerDef["trophies"].ToString();
            }
        }, defParams);
    }

    public void OnUserNicknameClick() { UnityEngine.SceneManagement.SceneManager.LoadScene("UserDetails"); }
    public void OnBrawlerClick() { UnityEngine.SceneManagement.SceneManager.LoadScene("BrawlerDetails"); }
    public void OnBrawlersButtonClick() { UnityEngine.SceneManagement.SceneManager.LoadScene("Brawlers"); }
    public void OnBattleLogButtonClick() { UnityEngine.SceneManagement.SceneManager.LoadScene("BattleLog"); }
}