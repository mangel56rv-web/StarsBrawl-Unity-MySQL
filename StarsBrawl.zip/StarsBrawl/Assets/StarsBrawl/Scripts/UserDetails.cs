using TMPro;
using UnityEngine;
using UnityEngine.UI;
using MySqlConnector;

public class UserDetails : MonoBehaviour
{
    [Header("Textos Principales")]
    [SerializeField] private TMP_Text usernameText;
    [SerializeField] private TMP_Text totalTrophiesText;
    [SerializeField] private TMP_Text brawlersCountText;

    [Header("Estadisticas de Combate")]
    [SerializeField] private TMP_Text victorias3vs3Text;
    [SerializeField] private TMP_Text victoriasSupervText;
    [SerializeField] private TMP_Text rachaActualText;

    [Header("Destacados y Favoritos")]
    [SerializeField] private TMP_Text brawlerFavoritoText;
    [SerializeField] private TMP_Text brawlerTriunfadorText;
    [SerializeField] private TMP_Text modoFavoritoText;

    [Header("Imagen del Rango Global")]
    [SerializeField] private Image globalRankIconDisplay;

    private void Start()
    {
        CargarPerfilDelUsuario();
    }

    private void CargarPerfilDelUsuario()
    {
        if (usernameText != null)
        {
            usernameText.text = "PRO BRAWLER";
        }

        string userIdActual = "1";
        if (DatabaseManager.Instance != null && !string.IsNullOrEmpty(DatabaseManager.CurrentUserId))
        {
            userIdActual = DatabaseManager.CurrentUserId;
        }

        string query = @"
            SELECT 
                COALESCE((SELECT SUM(trophies) FROM user_brawlers WHERE user_id = @userId), 0) AS total_trophies,
                (SELECT COUNT(*) FROM user_brawlers WHERE user_id = @userId) AS unlocked_brawlers,
                (SELECT COUNT(*) FROM brawlers) AS total_brawlers;";

        MySqlParameter[] parameters = {
            new MySqlParameter("@userId", userIdActual)
        };

        DatabaseManager.Instance.ExecuteQuery(query, (reader) =>
        {
            if (reader.Read())
            {
                int totalTrophies = reader.GetInt32("total_trophies");
                int unlocked = reader.GetInt32("unlocked_brawlers");
                int total = reader.GetInt32("total_brawlers");

                if (totalTrophies == 0 && unlocked > 0)
                {
                    totalTrophies = unlocked * 250;
                }

                if (totalTrophiesText != null)
                {
                    totalTrophiesText.text = totalTrophies.ToString();
                }

                if (brawlersCountText != null)
                {
                    brawlersCountText.text = unlocked + "/" + total;
                }

                ActualizarIconoDeRangoGlobal(totalTrophies);
                ObtenerBrawlersDestacados(userIdActual);
                CalcularEstadisticasDeCombate(totalTrophies);
            }
        }, parameters);
    }

    private void ObtenerBrawlersDestacados(string userIdActual)
    {
        string brawlerQuery = @"
            SELECT b.name 
            FROM user_brawlers ub
            JOIN brawlers b ON ub.brawler_id = b.brawler_id
            WHERE ub.user_id = @userId
            ORDER BY ub.trophies DESC
            LIMIT 1;";

        MySqlParameter[] brawlerParams = {
            new MySqlParameter("@userId", userIdActual)
        };

        DatabaseManager.Instance.ExecuteQuery(brawlerQuery, (brawlerReader) =>
        {
            string brawlerDestacado = "SHELLY";

            if (brawlerReader.Read())
            {
                brawlerDestacado = brawlerReader["name"].ToString().ToUpper();
            }

            if (brawlerFavoritoText != null) brawlerFavoritoText.text = brawlerDestacado;
            if (brawlerTriunfadorText != null) brawlerTriunfadorText.text = brawlerDestacado;
        }, brawlerParams);
    }

    private void CalcularEstadisticasDeCombate(int copasTotales)
    {
        int victorias3vs3 = Mathf.RoundToInt(copasTotales * 0.4f);
        int victoriasSuperv = Mathf.RoundToInt(copasTotales * 0.25f);
        int rachaActual = copasTotales > 100 ? Random.Range(3, 9) : Random.Range(0, 2);

        if (victorias3vs3Text != null) victorias3vs3Text.text = victorias3vs3.ToString();
        if (victoriasSupervText != null) victoriasSupervText.text = victoriasSuperv.ToString();
        if (rachaActualText != null) rachaActualText.text = rachaActual.ToString();

        if (modoFavoritoText != null)
        {
            modoFavoritoText.text = victorias3vs3 >= victoriasSuperv ? "BALON BRAWL" : "SUPERVIVENCIA";
        }
    }

    private void ActualizarIconoDeRangoGlobal(int copasTotales)
    {
        string spriteName = "icon_rank_sticker_bronze";

        if (copasTotales >= 200 && copasTotales < 600) spriteName = "icon_rank_sticker_silver";
        else if (copasTotales >= 600 && copasTotales < 1200) spriteName = "icon_rank_sticker_gold";
        else if (copasTotales >= 1200 && copasTotales < 2000) spriteName = "icon_rank_sticker_diamond";
        else if (copasTotales >= 2000 && copasTotales < 3000) spriteName = "icon_rank_sticker_mythic";
        else if (copasTotales >= 3000 && copasTotales < 4500) spriteName = "icon_rank_sticker_legendary";
        else if (copasTotales >= 4500 && copasTotales < 6000) spriteName = "icon_rank_sticker_pro";
        else if (copasTotales >= 6000) spriteName = "icon_rank_sticker_masters";

        Sprite rankSprite = Resources.Load<Sprite>("UI&Icons/Ranks/" + spriteName);
        if (rankSprite == null) rankSprite = Resources.Load<Sprite>("Ranks/" + spriteName);
        if (rankSprite == null) rankSprite = Resources.Load<Sprite>(spriteName);

        if (rankSprite != null && globalRankIconDisplay != null)
        {
            globalRankIconDisplay.sprite = rankSprite;
            globalRankIconDisplay.color = Color.white;
        }
    }

    public void OnBackButtonClick()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu");
    }
}