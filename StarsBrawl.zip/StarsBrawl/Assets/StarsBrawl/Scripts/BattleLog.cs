using TMPro;
using UnityEngine;
using UnityEngine.UI;
using MySqlConnector;

public class BattleLog : MonoBehaviour
{
    [Header("Grid System")]
    [SerializeField] private Transform logContainer;
    [SerializeField] private GameObject matchRowPrefab;

    private void Start()
    {
        foreach (Transform child in logContainer)
        {
            Destroy(child.gameObject);
        }

        CargarHistorialDeBatallas();
    }

    private void CargarHistorialDeBatallas()
    {
        string query = @"
            SELECT mu.match_id, mu.result, mt.name AS mode_name
            FROM match_user mu
            JOIN matches m ON mu.match_id = m.match_id
            JOIN match_types mt ON m.match_type_id = mt.match_type_id
            LIMIT 10;";

        DatabaseManager.Instance.ExecuteQuery(query, (reader) =>
        {
            int contador = 0;
            while (reader.Read())
            {
                string matchId = reader["match_id"].ToString();
                string mode = reader["mode_name"].ToString().ToUpper();
                string result = reader["result"].ToString().ToUpper();
                int trophies = (result == "VICTORIA" || result == "VICTORY") ? 8 : -4;

                GameObject row = Instantiate(matchRowPrefab, logContainer);

                TMP_Text[] texts = row.GetComponentsInChildren<TMP_Text>(true);
                foreach (TMP_Text t in texts)
                {
                    if (t.gameObject.name == "Match Modality Text") t.text = mode;
                    else if (t.gameObject.name == "Match Result Text") t.text = result;
                    else if (t.gameObject.name == "Match Type Text")
                    {
                        t.text = trophies >= 0 ? "+" + trophies + " COPAS" : trophies + " COPAS";
                    }
                    else if (t.gameObject.name == "Match Time Ago Text") t.text = "RECIENTE";
                }

                Button detallesBtn = null;
                Button[] botones = row.GetComponentsInChildren<Button>(true);
                foreach (Button b in botones)
                {
                    if (b.gameObject.name == "Match Details Button")
                    {
                        detallesBtn = b;
                        break;
                    }
                }

                if (detallesBtn != null)
                {
                    detallesBtn.onClick.RemoveAllListeners();
                    detallesBtn.onClick.AddListener(() => OnMatchClicked(matchId));
                }
                else
                {
                    Button rowBtn = row.GetComponent<Button>();
                    if (rowBtn == null) rowBtn = row.AddComponent<Button>();
                    rowBtn.onClick.RemoveAllListeners();
                    rowBtn.onClick.AddListener(() => OnMatchClicked(matchId));
                }

                contador++;
            }
        }, null);
    }

    private void OnMatchClicked(string matchId)
    {
        DatabaseManager.SelectedMatchId = matchId;
        UnityEngine.SceneManagement.SceneManager.LoadScene("MatchDetails");
    }

    public void OnBackButtonClick()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu");
    }
}
