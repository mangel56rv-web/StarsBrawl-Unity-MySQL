using TMPro;
using UnityEngine;
using MySqlConnector;

public class BrawlerDetails : MonoBehaviour
{
    [Header("Panel Izquierdo")]
    [SerializeField] private TMP_Text brawlerNameText;
    [SerializeField] private TMP_Text classAndRarityText;
    [SerializeField] private TMP_Text descriptionText;
    [SerializeField] private TMP_Text traitDescriptionText;

    [Header("Panel Derecho (Estad�sticas)")]
    [SerializeField] private TMP_Text levelText;
    [SerializeField] private TMP_Text healthText;
    [SerializeField] private TMP_Text damageText;
    [SerializeField] private TMP_Text superNameText;

    private void Start()
    {
        if (string.IsNullOrEmpty(DatabaseManager.SelectedBrawlerId))
        {
            Debug.LogWarning("No se ha seleccionado ning�n brawler.");
            return;
        }

        CargarDatosDelBrawler();
    }

    private void CargarDatosDelBrawler()
    {
        string query = @"
            SELECT 
                b.name AS brawler_name,
                b.description,
                IFNULL(ub.level, 1) AS current_level
            FROM brawlers b
            LEFT JOIN user_brawlers ub ON b.brawler_id = ub.brawler_id AND ub.user_id = @userId
            WHERE b.brawler_id = @brawlerId;";

        MySqlParameter[] parameters = {
            new MySqlParameter("@userId", DatabaseManager.CurrentUserId),
            new MySqlParameter("@brawlerId", DatabaseManager.SelectedBrawlerId)
        };

        DatabaseManager.Instance.ExecuteQuery(query, (reader) =>
        {
            if (reader.Read())
            {
                string rawName = reader["brawler_name"].ToString();
                string nameInUppercase = rawName.ToUpper();

                if (brawlerNameText != null) brawlerNameText.text = nameInUppercase;
                if (descriptionText != null) descriptionText.text = reader["description"].ToString();

                int level = reader.GetInt32("current_level");
                if (levelText != null) levelText.text = "FUERZA " + level;

                // --- ASIGNACI�N DE CLASES Y RAREZAS REALES ---
                string claseYRareza = "DESTRUCTOR | ESPECIAL";
                string descripcionAtributo = "Este brawler no posee rasgos pasivos.";
                string nombreSuper = "�SUPER ATAQUE!";

                switch (nameInUppercase)
                {
                    case "NANI":
                        claseYRareza = "TIRADOR | �PICO";
                        descripcionAtributo = "Lanza tres orbes de luz que se mueven en �ngulos para converger en un objetivo.";
                        nombreSuper = "TELEDIRIGIDO";
                        break;
                    case "SHELLY":
                        claseYRareza = "DESTRUCTORA | INICIAL";
                        descripcionAtributo = "Carga su S�per al infligir da�o a los enemigos.";
                        nombreSuper = "SUPERBALAS";
                        break;
                    case "EL PRIMO":
                        claseYRareza = "TANQUE | ESPECIAL";
                        descripcionAtributo = "Carga su S�per al recibir da�o de enemigos.";
                        nombreSuper = "CODAZO INTERESTELAR";
                        break;
                    case "BARLEY":
                        claseYRareza = "CONTROL | ESPECIAL";
                        descripcionAtributo = "Lanza botellas que crean charcos da�inos en el suelo.";
                        nombreSuper = "C�CTEL REVENT�N";
                        break;
                    case "MORTIS":
                        claseYRareza = "ASESINO | M�TICO";
                        descripcionAtributo = "Se desplaza hacia adelante con cada ataque b�sico.";
                        nombreSuper = "TRANSILVANIA";
                        break;
                }

                if (classAndRarityText != null) classAndRarityText.text = claseYRareza;
                if (traitDescriptionText != null) traitDescriptionText.text = descripcionAtributo;
                if (superNameText != null) superNameText.text = nombreSuper;

                // Estad�sticas seg�n nivel
                int baseHealth = 3200;
                int baseDamage = 840;
                if (healthText != null) healthText.text = (baseHealth + (level * 160)).ToString();
                if (damageText != null) damageText.text = (baseDamage + (level * 42)).ToString();
            }
        }, parameters);
    }

    public void OnBackButtonClick()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("Brawlers");
    }
}