using TMPro;
using UnityEngine;
using UnityEngine.UI;
using MySqlConnector;

public class BrawlersList : MonoBehaviour
{
    [Header("Grid System")]
    [SerializeField] private Transform gridContainer;
    [SerializeField] private GameObject brawlerCardPrefab;

    [Header("Top Info")]
    [SerializeField] private TMP_Text totalBrawlersText;

    private void Start()
    {
        foreach (Transform child in gridContainer)
        {
            Destroy(child.gameObject);
        }

        CargarBrawlersDelUsuario();
    }

    private void CargarBrawlersDelUsuario()
    {
        string query = @"
            SELECT 
                b.brawler_id, 
                b.name AS brawler_name, 
                IF(ub.user_id IS NOT NULL, 1, 0) AS unlocked,
                IFNULL(ub.trophies, 0) AS trophies,
                IFNULL(ub.level, 1) AS level
            FROM brawlers b
            LEFT JOIN user_brawlers ub ON b.brawler_id = ub.brawler_id AND ub.user_id = @userId
            ORDER BY unlocked DESC, trophies DESC, b.name ASC;";

        MySqlParameter[] parameters = { new MySqlParameter("@userId", DatabaseManager.CurrentUserId) };

        int unlockedCount = 0;
        int totalBrawlersCount = 0;

        DatabaseManager.Instance.ExecuteQuery(query, (reader) =>
        {
            while (reader.Read())
            {
                totalBrawlersCount++;
                bool isUnlocked = reader.GetInt32("unlocked") == 1;
                string brawlerId = reader["brawler_id"].ToString();
                string name = reader["brawler_name"].ToString();
                int trophies = reader.GetInt32("trophies");
                int level = reader.GetInt32("level");

                if (isUnlocked) unlockedCount++;

                GameObject card = Instantiate(brawlerCardPrefab, gridContainer);

                // Asignar textos
                TMP_Text[] texts = card.GetComponentsInChildren<TMP_Text>(true);
                foreach (TMP_Text t in texts)
                {
                    if (t.gameObject.name == "Brawler Name") t.text = name;
                    else if (t.gameObject.name == "Text (TMP)") t.text = level.ToString();
                    else if (t.gameObject.name == "Trophies Amount") t.text = trophies.ToString();
                }

                //  CARGAR ICONO DIN�MICAMENTE CON LIMPIEZA DE CARACTERES ESPECIALES
                Image brawlerIcon = null;
                Image[] allImages = card.GetComponentsInChildren<Image>(true);
                foreach (Image img in allImages)
                {
                    if (img.gameObject.name == "Brawler Image")
                    {
                        brawlerIcon = img;
                        break;
                    }
                }

                if (brawlerIcon != null)
                {
                    
                    string cleanName = name.ToLower();

                   
                    cleanName = cleanName.Replace(" ", "");  
                    cleanName = cleanName.Replace("-", ""); 
                    cleanName = cleanName.Replace(".", "");  

                    
                    string portraitPath = "Brawlers/Portraits/" + cleanName + "_portrait";
                    Sprite portraitSprite = Resources.Load<Sprite>(portraitPath);

                   
                    if (portraitSprite != null)
                    {
                        brawlerIcon.sprite = portraitSprite;
                    }
                    else
                    {
                        Debug.LogWarning($"[RESOURCES] No se encontr� el retrato en la ruta: Brawlers/Portraits/{cleanName}_portrait");
                    }
                }

               
                if (!isUnlocked)
                {
                    foreach (var img in allImages)
                    {
                        img.color = new Color(0.25f, 0.25f, 0.25f, 1f);
                    }
                }

               
                Transform brawlerPanel = card.transform.Find("Brawler Panel");
                if (brawlerPanel == null)
                {
                    foreach (Transform child in card.GetComponentsInChildren<Transform>(true))
                    {
                        if (child.name == "Brawler Panel") { brawlerPanel = child; break; }
                    }
                }

                GameObject targetClickObject = brawlerPanel != null ? brawlerPanel.gameObject : card;
                Button btn = targetClickObject.GetComponent<Button>();
                if (btn == null) btn = targetClickObject.AddComponent<Button>();
                btn.onClick.RemoveAllListeners();
                btn.onClick.AddListener(() => OnBrawlerSelected(brawlerId));
                btn.interactable = true;
            }

            if (totalBrawlersText != null) totalBrawlersText.text = $"{unlockedCount}/{totalBrawlersCount}";
        }, parameters);
    }

    private void OnBrawlerSelected(string brawlerId)
    {
        DatabaseManager.SelectedBrawlerId = brawlerId;
        UnityEngine.SceneManagement.SceneManager.LoadScene("BrawlerDetails");
    }

    public void OnBackButtonClick()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu");
    }
}